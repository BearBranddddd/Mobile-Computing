//
//  CA04_Bernardo_Frederick_Kowe_0706022310049Tests.swift
//  CA04_Bernardo Frederick Kowe_0706022310049Tests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import CA04_Bernardo_Frederick_Kowe_0706022310049

struct CA04_Bernardo_Frederick_Kowe_0706022310049Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
