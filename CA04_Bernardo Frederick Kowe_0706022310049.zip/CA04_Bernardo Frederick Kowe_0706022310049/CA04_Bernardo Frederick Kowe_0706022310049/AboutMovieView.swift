//
//  AboutMovieView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct AboutMovieView: View {
    let movie: Movie
    
    var body: some View {
        Text("About \(movie.title)")
            .font(.title)
            .padding()
        Text("\(movie.detail)")
            .padding()
    }
}
