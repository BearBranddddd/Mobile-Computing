//
//  MovieGridView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieGridView: View {
    @ObservedObject var store: MovieStore
    @Binding var selectedMovie: Movie?
    
    let columns = [ GridItem(.flexible()), GridItem(.flexible()) ]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(store.filteredMovies) { movie in
                    Button {
                        selectedMovie = movie
                    } label: {
                        MovieCard(movie: movie)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding()
        }
    }
}

