//
//  CA04_Bernardo_Frederick_Kowe_0706022310049App.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct CA04_Bernardo_Frederick_Kowe_0706022310049App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
