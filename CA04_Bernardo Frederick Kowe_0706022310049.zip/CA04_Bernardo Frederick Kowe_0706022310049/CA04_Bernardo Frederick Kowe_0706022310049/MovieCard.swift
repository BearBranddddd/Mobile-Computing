//
//  MovieCard.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCard: View {
    let movie: Movie
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            AsyncImage(url: URL(string: movie.url)) { image in
                image
                    .resizable()
                    .scaledToFill()
            } placeholder: {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
            }
            .frame(width: 140, height: 200)
            .clipped()
            .cornerRadius(10)
            
            Text(movie.title)
                .font(.headline)
                .lineLimit(1)
            
            Text(movie.genre)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            HStack(spacing: 4) {
                ForEach(1...5, id: \.self) { index in
                    Image(systemName: index <= Int(movie.rating.rounded()) ? "star.fill" : "star")
                        .foregroundColor(.yellow)
                        .font(.caption2)
                }
                Text(String(format: "%.1f", movie.rating))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Text("Year: \(movie.year)")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(width: 170, height: 330)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 4)
    }
}
