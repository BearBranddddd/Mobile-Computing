//
//  ContentView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movie: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let genre: String
    let url: String
    let detail : String
    let cast : [String]
    let rating: Double
    let year: String
}

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(title: "The Dark Knight",
              genre: "Action",
              url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwv-Qq9UZt5sUxo4GApaotRF9H-XDiNwUyNw&s",
              detail:"Intine seru batman batman an wess lawan boss sampek suksess GACOR",
              cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
              rating: 4.8,
              year: "2008"),
        
        Movie(title: "Narik Sukmo",
              genre: "Horror",
              url: "https://cdns.klimg.com/resized/670x/g/d/e/deretan_film_horor_yang_tayang_di_bioskop_bulan_juli_2025_awas_jangan_sampe_terlewat/p/film_horor_yang_tayang_di_bioskop_bulan_juli_2025-20250707-002-non_fotografer_kly.jpg",
              detail: "Intine iki film horror jawa serem banget setan e setan indo",
              cast: ["Actor A", "Actor B", "Actor C"],rating: 4.5,
              year: "2023"),
        
        Movie(title: "Misteri Rumah Darah",
              genre: "Horror",
              url: "https://dorangadget.com/wp-content/uploads/2025/03/Film-Horor-Indonesia-Misteri-Rumah-Darah-566x800.jpg",
              detail : "Membahas misteri rumah darah yang bekas pembunuhan",
              cast: ["Actor D", "Actor E"],rating: 4.2,
              year: "2020"),
        
        Movie(title: "Perewangan",
              genre: "Horror",
              url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUJ69tZhcKn7fBTusIbhBXPyi-lQEy8aH61g&s",
              detail: "Membahas setan kematian",
              cast: ["Actor F", "Actor G"],rating: 3.9,
              year: "2018"),
        
        Movie(title: "Mission: Impossible",
              genre: "Action",
              url: "https://akcdn.detik.net.id/community/media/visual/2023/09/01/film-action-terbaik-mission-impossible-dead-reckoning-part-one-2023.jpeg?w=620&q=90",
              detail:"Film action sg GUACOR abisss action e menegangkan semua eakk eakk eakk",
              cast: ["Tom Cruise", "Rebecca Ferguson", "Simon Pegg"],rating: 4.2,
              year: "2021")
    ]
    
    @Published var searchText: String = ""
    
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return movies
        } else {
            return movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }
}

struct ContentView: View {
    @StateObject private var store = MovieStore()
    @State private var selectedMovie: Movie? = nil
    
    var body: some View {
        NavigationStack {
            VStack {
                SearchBar(text: $store.searchText)
                
                MovieGridView(store: store, selectedMovie: $selectedMovie)
            }
            .navigationTitle("UCFlix")
            .navigationDestination(item: $selectedMovie) { movie in
                MovieDetailView(movie: movie)
            }
        }
    }
}


struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        TextField("Search movies...", text: $text)
            .padding(10)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)
    }
}

#Preview {
    ContentView()
}
