//
//  CastIntoView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct CastInfoView: View {
    let movie: Movie
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Cast Info for \(movie.title)")
                .font(.title)
                .padding(.bottom)
            
            ForEach(movie.cast, id: \.self) { castMember in
                Text("• \(castMember)")
                    .font(.body)
            }
            
            Spacer()
        }
        .padding()
    }
}
