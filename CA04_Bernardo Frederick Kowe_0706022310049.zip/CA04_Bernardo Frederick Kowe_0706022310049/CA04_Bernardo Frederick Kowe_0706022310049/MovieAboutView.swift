//
//  MovieAboutView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieAboutView: View {
    let movie: Movie

    var body: some View {
        VStack(spacing: 20) {
            Text("About \(movie.title)")
                .font(.largeTitle)
                .bold()

            Text("Detailed info, cast, trivia, etc.")
                .font(.body)
                .padding()

            Spacer()
        }
        .padding()
        .navigationTitle("About Movie")
        .navigationBarTitleDisplayMode(.inline)
    }
}
