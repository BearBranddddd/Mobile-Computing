//
//  MovieDetailView.swift
//  CA04_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                AsyncImage(url: URL(string: movie.url)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(10)
                } placeholder: {
                    Color.gray.opacity(0.3)
                }
                .frame(height: 300)
                
                Text(movie.title)
                    .font(.largeTitle)
                    .bold()
                Text(movie.genre)
                    .font(.title2)
                    .foregroundColor(.secondary)

                
                HStack{
                    NavigationLink("About Movie", destination: AboutMovieView(movie: movie))
                        .padding()
                        .background(Color.blue.opacity(0.2))
                        .cornerRadius(8)
                    
                    NavigationLink("Cast Info", destination: CastInfoView(movie: movie))
                        .padding()
                        .background(Color.green.opacity(0.2))
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

