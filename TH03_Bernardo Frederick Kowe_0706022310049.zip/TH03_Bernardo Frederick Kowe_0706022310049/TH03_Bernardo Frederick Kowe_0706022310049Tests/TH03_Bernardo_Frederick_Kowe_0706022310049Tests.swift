//
//  TH03_Bernardo_Frederick_Kowe_0706022310049Tests.swift
//  TH03_Bernardo Frederick Kowe_0706022310049Tests
//
//  Created by student on 26/09/25.
//

import Testing
@testable import TH03_Bernardo_Frederick_Kowe_0706022310049

struct TH03_Bernardo_Frederick_Kowe_0706022310049Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
