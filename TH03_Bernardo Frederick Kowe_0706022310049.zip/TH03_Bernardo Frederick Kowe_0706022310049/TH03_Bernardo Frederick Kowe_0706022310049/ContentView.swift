//
//  ContentView.swift
//  TH03_Mobile Computing
//
//  Created by student on 25/09/25.
//
import SwiftUI
struct ContentView: View {

    var body: some View {
        
        
        TabView {
            HomeView()
                .tabItem{
                    Label("Home", systemImage: "house.fill")
                }
            Activity()
                .tabItem{
                    Label("Activity", systemImage: "bolt.fill")
                }
            Stats()
                .tabItem{
                    Label("Stats", systemImage: "chart.bar.fill")
                }
            Setting()
                .tabItem{
                    Label("Settings", systemImage: "gearshape.fill")
                }
        }
        .tint(.red)
    }
}

struct Goal: View {
    var icon: String
    var jarak: String
    var name: String
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 50))
                .frame(width: 30,height: 60)
                .foregroundColor(.white)
            Text(jarak)
                .font(.system(size:20))
                .bold()
                .foregroundColor(.white)
            Text(name)
                .font(.custom("Times New Roman", size: 14))
                .foregroundColor(.white.opacity(0.8))
        }
        .frame(width: 140, height: 150)
        .background(Color.white.opacity(0.15))
        .cornerRadius(20)
        .padding(.bottom,8)
    }
}
struct Status: View {
    
    var icon: String
    var nilai: String
    var warna: Color
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(warna)
                .font(.system(size: 24))
                .padding(.top,-26)
                .padding(.leading, -1)
            Text(nilai)
                .font(.system(size: 20))
                .padding(.top,30)
                .frame(maxWidth: 100, alignment: .trailing)
        }
        .frame(width: 170, height: 80)
        .background(.white)
        .cornerRadius(25)
    }
}

struct HomeView:View{
    @State private var nama: String = ""
    var body: some View{
        ZStack{
            VStack(alignment: .leading, spacing: 20) {
                HStack {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("Good Morning,")
                            .font(.custom("Times New Roman", size: 25))
                            .opacity(0.7)
                        Text("Bernard")
                            .font(.system(size:35))
                            .fontWeight(.bold)
                    }
                    Spacer()
                    Image("muka")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 65, height: 65)
                        .cornerRadius(25)
                }
                .padding(.horizontal)
                
                TextField("Search", text: $nama)
                    .padding(12)
                    .background(.white)
                    .cornerRadius(12)
                    .padding(.horizontal,20)
                    .padding(.vertical,15)
                VStack(alignment: .center, spacing: 16) {
                    Text("Today's Goal")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.vertical,8)
                    HStack(spacing: 16) {
                        Goal(icon: "figure.walk", jarak: "4 Miles", name: "@Thames Route")
                        Goal(icon: "figure.rower", jarak: "2 Miles", name: "@River Lea")
                    }
                }
                .padding()
                .frame(maxWidth: 400)
                .background(
                    LinearGradient(gradient: Gradient(colors: [.blue.opacity(0.9),Color.pink.opacity(0.6), Color.red]),
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                )
                .cornerRadius(24)
                .padding(.horizontal)
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        Status(icon: "heart.fill", nilai: "68 Bpm", warna: .purple)
                        Status(icon: "flame.fill", nilai: "0 Kcal", warna: .orange)
                    }
                    HStack(spacing: 16) {
                        Status(icon: "scalemass.fill", nilai: "73 Kg", warna: .green)
                        Status(icon: "moon.zzz.fill", nilai: "6.2 Hr", warna: .blue)
                    }
                }
                .padding(.top,10)
                .frame(maxWidth: 400)
                Spacer()
            }
            .padding(.top, 80)
            .frame(width: 385)
        }
        .frame(width: 400,height: 770)
        .background(.gray.opacity(0.1))
        .cornerRadius(35)
        .ignoresSafeArea()
    }
}
struct Activity:View{
    var body: some View{
        Text("Ini Activity")
    }
}
struct Stats:View{
    var body: some View{
        Text("Ini Stats")
    }
}
struct Setting:View{
    var body: some View{
        Text("Ini Setting")
    }
}

#Preview {
    ContentView()
}


