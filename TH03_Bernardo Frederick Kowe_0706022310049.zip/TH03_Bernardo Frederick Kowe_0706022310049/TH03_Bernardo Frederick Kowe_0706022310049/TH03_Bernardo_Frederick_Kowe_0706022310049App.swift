//
//  TH03_Bernardo_Frederick_Kowe_0706022310049App.swift
//  TH03_Bernardo Frederick Kowe_0706022310049
//
//  Created by student on 26/09/25.
//

import SwiftUI

@main
struct TH03_Bernardo_Frederick_Kowe_0706022310049App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
