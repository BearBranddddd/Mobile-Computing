//
//  W01_MobCompApp.swift
//  W01_MobComp
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_MobCompApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
