//
//  ContentView.swift
//  W01_MobComp
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct Student{
    var name: String
    var year:Int
    func display() -> String {
        "\(name) - \(year)"
    }
}

enum UserStatus {case offline, online, busy}

struct ContentView: View {
    let userName = "Bernard"
    let scores = [90,92,91]
    let student = Student(name:"Huha", year:2)
    let status: UserStatus = .online
    
    var badge: String {
        scores.allSatisfy {$0 >= 85} ? "✅" : "❌"
    }
    var body: some View {
//        VStack{
//            Text("Hello, \(userName)!")
//            Text("Your status is: \(status)")
//            Text("Your badge is: \(badge)")
//        }
        VStack {
            
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
//            Text("Hello, Bernard!")
//                .font(.largeTitle)
//                .fontWeight(.bold)
//                .padding(.horizontal)
//            
//            Text("Declarative UI | Live Preview | SwifrUI Cool!")
//                .multilineTextAlignment(.center)
//                .padding()
//                .font(.headline)
//                .background(.ultraThinMaterial)
//                .clipShape(RoundedRectangle(cornerRadius: 16))
//            
//            Image(systemName: "sparkles")
//                .imageScale(.large)
//                .font(.system(size: 100))
//                .padding()
//                .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]),
//                    startPoint: .top,
//                    endPoint: .bottom))
//                .overlay(content: {
//                    Circle().strokeBorder(.orange.opacity(0.3),lineWidth:3)
//                }
//            )
            
//            var -> variabel nilainya bisa berubah
//            let -> constanta nilainya tidak bisa berubah
//            HStack{
//                Text("😩")
//                    .font(.system(size: 150))
//                Text("😊")
//                    .font(.system(size: 150))
//            }
            
            //CLASS ASS
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.cyan, .white]),
                                       startPoint: .top,
                                       endPoint: .bottom)
                            .edgesIgnoringSafeArea(.all)
                            .frame(width: 500,height: 800)
                VStack(){
                    
                    Image("phot")
                                    .resizable()
                                    .frame(width:300, height:250)
                                    .clipShape(Circle())
                                    .shadow(color:.blue, radius: 40)
                                    .padding(.bottom, 100)
                                    .padding(.top,40)
                    Text("Hi!, I'm Bernard")
                        .font(.system(size: 30))
                        .padding(.vertical, 10)
                        .padding(.horizontal, 20)
                        .background(Color.blue.opacity(0.2))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .fontWeight(.bold)
                    Text("")
                        .padding(.bottom,3)
                    
                        
                    Text("My age is 20")
                        .font(.system(size: 30))
                        .padding(.vertical, 10)
                        .padding(.horizontal, 20)
                        .background(Color.blue.opacity(0.2))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .fontWeight(.bold)
                    
                    Text("")
                        .padding(.bottom,10)
                    Text("😇  😇  😇")
                        .font(.system(size: 60))

                    
                    Spacer()
                }
                .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.black, Color.blue]),
                                                startPoint: .center,
                                                endPoint: .leading))
            }
            }
            
//        HStack(/*alignment: .leading,*/ spacing: 15){
//            
////            HStack(spacing: 12){
////                    Text("Ter")
////                    Text("se")
////                    Text("rah")
////            }
////            
////            VStack(spacing: 12){
////                    Text("Ter")
////                    Text("se")
////                    Text("rah")
////            }
////            
////            ZStack(){
////                    Text("Ter")
////                    Text("se")
////                    Text("rah")
////            }
//            
//            VStack(spacing: 12){
//                Text("🙈")
//                .font(.system(size: 100))
//                Text("👀")
//                .font(.system(size: 100))
//                Text("🥶")
//                .font(.system(size: 100))
//            }
//            
//            VStack(spacing: 12){
//                Text("🫀")
//                .font(.system(size: 100))
//                Text("💋")
//                .font(.system(size: 100))
//                Text("🫁")
//                .font(.system(size: 100))
//            }
//            
//            VStack(spacing: 12){
//                Text("👅")
//                .font(.system(size: 100))
//                Text("👣")
//                .font(.system(size: 100))
//                Text("👑")
//                .font(.system(size: 100))
//            }
//        }
        .padding()

    }
    let name = "Bernard"
    var age = 20
    func greet(){
        print("Hello, \(name), age \(age)")
    }
    
}

#Preview {
    ContentView()
}
