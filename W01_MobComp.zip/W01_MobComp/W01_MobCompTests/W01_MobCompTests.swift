//
//  W01_MobCompTests.swift
//  W01_MobCompTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_MobComp

struct W01_MobCompTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
